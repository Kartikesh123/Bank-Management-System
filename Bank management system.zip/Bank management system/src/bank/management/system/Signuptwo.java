package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import com.toedter.calendar.JDateChooser;

public class Signuptwo extends JFrame implements ActionListener{
    
    
    long random;
    JTextField nameTextField,fnameTextField,emailTextField,addressTextField,stateTextField,cityTextField,pincodeTextField,pan,aadhar;
    JButton next;
    JRadioButton male,female,married,unmarried,others,Yes,No;
    JDateChooser datechooser;
    JComboBox religion,category,income,qualification,occupation;
    
    String formno;

    Signuptwo(String formno) {
        
        this.formno = formno;
        setLayout(null);

        Random ran = new Random();
        random = Math.abs((ran.nextLong() % 9000L) + 1000L);
        
        setTitle("Application Form - Page 2");

        JLabel additionalDetails = new JLabel("Page 2: Additional Details ");
        additionalDetails.setFont(new Font("Raleway", Font.BOLD, 22));
        additionalDetails.setBounds(290, 80, 400, 30);
        add(additionalDetails);

        JLabel r = new JLabel("Religion: ");
        r.setFont(new Font("Raleway", Font.BOLD, 20));
        r.setBounds(100, 140, 100, 30);
        add(r);
        
        String ValReligion[] = {"Hindu","Muslim","Sikh","Cristain","Other"};
        religion = new JComboBox(ValReligion);
        religion.setBounds(300, 140, 400, 30);
        religion.setBackground(Color.WHITE);
        add(religion);


        JLabel ca = new JLabel("Category: ");
        ca.setFont(new Font("Raleway", Font.BOLD, 20));
        ca.setBounds(100, 190, 200, 30);
        add(ca);
        
        String ValCategory[] = {"General","OBC","SC","ST","Other"};
        category = new JComboBox(ValCategory);
        category.setBounds(300, 190, 400, 30);
        category.setBackground(Color.WHITE);
        add(category);
        

        JLabel i = new JLabel("Income: ");
        i.setFont(new Font("Raleway", Font.BOLD, 20));
        i.setBounds(100, 240, 200, 30);
        add(i);
        
        String ValIncome[] = {"Null","<1 lakh","<3 lakh","<5 lakh","<5 lakh"};
        income = new JComboBox(ValIncome);
        income.setBounds(300,240,400,30);
        income.setBackground(Color.WHITE);
        add(income);
        
       
       

        JLabel e = new JLabel("Educational ");
        e.setFont(new Font("Raleway", Font.BOLD, 20));
        e.setBounds(100, 290, 200, 30);
        add(e);
        

        JLabel q = new JLabel("Qualification: ");
        q.setFont(new Font("Raleway", Font.BOLD, 20));
        q.setBounds(100, 315, 200, 30);
        add(q);
        
        String ValQualification[] = {"Non-Graduate","Graduate","Post-Graduate","Doctrate","Other"};
        qualification = new JComboBox(ValQualification);
        qualification.setBounds(300, 315, 400, 30);
        qualification.setBackground(Color.WHITE);
        add(qualification);
        
        JLabel o = new JLabel("Occupation: ");
        o.setFont(new Font("Raleway", Font.BOLD, 20));
        o.setBounds(100, 390, 200, 30);
        add(o);
        
        String ValOccupation[] = {"Salaried","Non-Salaried","Buisness","Student","Other"};
        occupation = new JComboBox(ValOccupation);
        occupation.setBounds(300, 390, 400, 30);
        occupation.setBackground(Color.WHITE);
        add(occupation);
        
        

        JLabel pn = new JLabel("Pan No: ");
        pn.setFont(new Font("Raleway", Font.BOLD, 20));
        pn.setBounds(100, 440, 200, 30);
        add(pn);

        pan = new JTextField();
        pan.setFont(new Font("Raleway", Font.BOLD, 14));
        pan.setBounds(300, 440, 400, 30);
        add(pan);

        JLabel an = new JLabel("Aadhar No: ");
        an.setFont(new Font("Raleway", Font.BOLD, 20));
        an.setBounds(100, 490, 200, 30);
        add(an);

        aadhar = new JTextField();
        aadhar.setFont(new Font("Raleway", Font.BOLD, 14));
        aadhar.setBounds(300, 490, 400, 30);
        add(aadhar);

        JLabel sc = new JLabel("Senior Citizen: ");
        sc.setFont(new Font("Raleway", Font.BOLD, 20));
        sc.setBounds(100, 540, 200, 30);
        add(sc);
        
        Yes = new JRadioButton("Yes");
        Yes.setBounds(300,540,100,30);
        Yes.setBackground(Color.WHITE);
        add(Yes);
        
        No = new JRadioButton("NO");
        No.setBounds(450,540,100,30);
        No.setBackground(Color.WHITE);
        add(No);
        
        
        ButtonGroup msgroup = new ButtonGroup();
        msgroup.add(Yes);
        msgroup.add(No);
       

        JLabel pincode = new JLabel("Exiting Account: ");
        pincode.setFont(new Font("Raleway", Font.BOLD, 20));
        pincode.setBounds(100, 590, 200, 30);
        add(pincode);

        Yes = new JRadioButton("Yes");
        Yes.setBounds(300,590,100,30);
        Yes.setBackground(Color.WHITE);
        add(Yes);
        
        No = new JRadioButton("NO");
        No.setBounds(450,590,100,30);
        No.setBackground(Color.WHITE);
        add(No);
        
        
        ButtonGroup emsgroup = new ButtonGroup();
        emsgroup.add(Yes);
        emsgroup.add(No);
        
        next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,640,80,30);
        next.addActionListener(this);
        add(next);
        
        getContentPane().setBackground(Color.WHITE);

        setSize(850, 800);
        setLocation(600, 50);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        String formno = "" + random;          //("" + long ) this converts the long into the String.
        String sreligion = (String) religion.getSelectedItem();
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String squalification = (String) qualification.getSelectedItem();
        String soccupation = (String) occupation.getSelectedItem();
        
        String seniorcitizen = null;
        if(Yes.isSelected())
        {
            seniorcitizen = "Yes";
        }else if(No.isSelected())
        {
            seniorcitizen = "No";
        }
        
        String exisitingaccount = null;
        if(Yes.isSelected())
        {
            exisitingaccount = "Yes";
        }
        else if(No.isSelected())
        {   exisitingaccount = "No";
        }
        
        
        String span = pan.getText();
        String saadhar = aadhar.getText();
        
        
        //exceptional handelling foro getting errors detection in databases
        try{
            if(income.equals("")){
                JOptionPane.showMessageDialog(null,"income is required");
            }else{
                conn c = new conn();
                String query = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+squalification +"','"+soccupation+"','"+span+"','"+saadhar+"','"+seniorcitizen+"','"+exisitingaccount+"')";
                c.s.executeUpdate(query);
                
                setVisible(false);
                new Signupthree(formno).setVisible(true);
            }
        }catch(Exception e){
            System.out.println(e);
        }
        
    }
    
    public static void main(String args[]) {

        new Signuptwo("");
    }
}
