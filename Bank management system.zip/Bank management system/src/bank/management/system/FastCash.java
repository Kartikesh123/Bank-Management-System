package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class FastCash extends JFrame implements ActionListener {
    
    JButton deposite,withdraw,fastcash,mini,pinchange,Binquiry,exit;
    String pinNumber;
    FastCash(String pinNumber) {
        this.pinNumber = pinNumber;
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));//imageicon is created an image is taken from the source
        Image i2 = i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);//imageicon is converted into th e image
        ImageIcon i3 = new ImageIcon(i2);//image is again converted into imageicon
        JLabel image = new JLabel(i3);//image jlabel is created to add image on frame
        image.setBounds(0, 0, 900, 900);
        add(image);//image is added 

        JLabel text = new JLabel("Select Withdrawl amount");
        text.setBounds(220, 300, 700, 35);
        text.setForeground(Color.white);
        text.setFont(new Font("System", Font.BOLD, 16));
        image.add(text);  //image.add() will add text over the image
        
        deposite = new JButton("Rs 100");
        deposite.setBounds(170,415,150,30);
        deposite.addActionListener(this);
        image.add(deposite);
        
        withdraw = new JButton("Rs 500");
        withdraw.setBounds(355,415,150,30);
        withdraw.addActionListener(this);
        image.add(withdraw);
        
        fastcash = new JButton("Rs 1000");
        fastcash.setBounds(170,450,150,30);
        fastcash.addActionListener(this);
        image.add(fastcash);
        
        mini = new JButton("Rs 2000");
        mini.setBounds(355,450,150,30);
        mini.addActionListener(this);
        image.add(mini);
        
        pinchange = new JButton("Rs 5000");
        pinchange.setBounds(170,485,150,30);
        pinchange.addActionListener(this);
        image.add(pinchange);
        
        Binquiry = new JButton("Rs 10000");
        Binquiry.setBounds(355,485,150,30);
        Binquiry.addActionListener(this);
        image.add(Binquiry);
        
        exit = new JButton("Back");
        exit.setBounds(355,520,150,30);
        exit.addActionListener(this);
        image.add(exit);
        
        
        setSize(900, 900);
        setLocation(500, 0);
       // setUndecorated(true);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        
        if(ae.getSource() == exit){
            setVisible(false);
            new Transactions(pinNumber).setVisible(true);
        }else 
        {
            String amount = ((JButton)ae.getSource()).getText().substring(3);//this will give us the text written on the button
            conn c = new conn();
            try{
                ResultSet rs = c.s.executeQuery("select * from bank where pinNumber = '"+pinNumber+"'");
                int balance = 0;
                while(rs.next()){
                    if(rs.getString("type").equals("Deposite")){
                        balance += Integer.parseInt(rs.getString("amount"));//Interger.parseInt() makes the string integer   
                    }else{
                        balance -= Integer.parseInt(rs.getString("amount"));
                    }
                }
                
                if(ae.getSource() != exit  && balance < Integer.parseInt(amount)){
                    JOptionPane.showMessageDialog(null, "Insufficient balance");
                }
                
                Date date = new Date();
                String query = "insert into bank values('"+pinNumber+"','"+date+"','Withdrawl','"+amount+"')";
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Rs" +amount+ "Debited successfully");
                
                setVisible(false);
                
                new Transactions(pinNumber).setVisible(true);
                
            }catch(Exception e){
                System.out.println(e);
            }
        }
    }

    public static void main(String args[]) {
        new FastCash("");
    }

}
