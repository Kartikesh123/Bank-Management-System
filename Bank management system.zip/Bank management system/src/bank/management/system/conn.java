

package bank.management.system;

import java.sql.*;

public class conn {
    Connection c;
    Statement s;
    public conn()
    {
        try{
            //creation of driver by class- Class
           c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","Kartik@1400");
           s = c.createStatement();
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
