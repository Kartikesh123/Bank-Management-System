package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Transactions extends JFrame implements ActionListener {
    
    JButton deposite,withdraw,fastcash,mini,pinchange,Binquiry,exit;
    String pinNumber;
    Transactions(String pinNumber) {
        this.pinNumber = pinNumber;
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));//imageicon is created an image is taken from the source
        Image i2 = i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);//imageicon is converted into th e image
        ImageIcon i3 = new ImageIcon(i2);//image is again converted into imageicon
        JLabel image = new JLabel(i3);//image jlabel is created to add image on frame
        image.setBounds(0, 0, 900, 900);
        add(image);//image is added 

        JLabel text = new JLabel("Please select your Transaction");
        text.setBounds(220, 300, 700, 35);
        text.setForeground(Color.white);
        text.setFont(new Font("System", Font.BOLD, 16));
        image.add(text);  //image.add() will add text over the image
        
        deposite = new JButton("Deposite");
        deposite.setBounds(170,415,150,30);
        deposite.addActionListener(this);
        image.add(deposite);
        
        withdraw = new JButton("Cash Withdrawal");
        withdraw.setBounds(355,415,150,30);
        withdraw.addActionListener(this);
        image.add(withdraw);
        
        fastcash = new JButton("Fast Cash");
        fastcash.setBounds(170,450,150,30);
        fastcash.addActionListener(this);
        image.add(fastcash);
        
        mini = new JButton("Mini Statement");
        mini.setBounds(355,450,150,30);
        mini.addActionListener(this);
        image.add(mini);
        
        pinchange = new JButton("Pin Change");
        pinchange.setBounds(170,485,150,30);
        pinchange.addActionListener(this);
        image.add(pinchange);
        
        Binquiry = new JButton("Balance Enquiry");
        Binquiry.setBounds(355,485,150,30);
        Binquiry.addActionListener(this);
        image.add(Binquiry);
        
        exit = new JButton("Exit");
        exit.setBounds(355,520,150,30);
        exit.addActionListener(this);
        image.add(exit);
        
        
        setSize(900, 900);
        setLocation(500, 0);
       // setUndecorated(true);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        
        if(ae.getSource() == exit){
            System.exit(0);
        }else if(ae.getSource() == deposite){
            setVisible(false);
            new Deposite(pinNumber).setVisible(true);
        }else if(ae.getSource() == withdraw){
            setVisible(false);
            new Withdrawl(pinNumber).setVisible(true);
        }else if(ae.getSource() == fastcash){
        setVisible(false);
        new FastCash(pinNumber).setVisible(true);
    }else if(ae.getSource() == pinchange){
        setVisible(false);
        new PinChange(pinNumber).setVisible(true); 
    }else if(ae.getSource() == Binquiry){
        setVisible(false);
        new BalanceEnquiry(pinNumber).setVisible(true);
    }else if(ae.getSource() == mini){  
        new MiniStatement(pinNumber).setVisible(true);
    }
    }

    public static void main(String args[]) {
        new Transactions("");
    }

}
